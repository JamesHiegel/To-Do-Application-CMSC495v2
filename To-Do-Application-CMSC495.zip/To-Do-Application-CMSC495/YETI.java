import static java.util.Collections.list;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ListView;
import javafx.scene.control.SplitPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.control.CheckBox;
import javafx.stage.Stage;

import java.util.List;

/**
 *
 * @author coryl
 */
public class YETI extends Application {

     ObservableList<String> data = FXCollections.observableArrayList(
            "Colors Needed for Art Project: ", "Salmon", "Gold", "Coral", "Darkorchid",
            "Darkgoldenrod", "Lightsalmon", "Black", "Rosybrown", "Blue",
            "Blueviolet", "Brown");




    @Override
    public void start(Stage primaryStage) {
        
        DatePicker datePicker = new DatePicker();
        ListView listView = new ListView();
        final TextField textField = new TextField();
        textField.setPromptText("Input new item to add to list here");

        Button addBtn = new Button("Add Item");
        CheckBox completedBox = new CheckBox("Done");  //trying to add Done checkbox.. to be continued
        completedBox.setIndeterminate(false);
        listView.setItems(data);
        listView.setPrefSize(490,300);  // just added prefSize @author lisa williford
        listView.setEditable(true);



        addBtn.setOnAction(new EventHandler<ActionEvent>() {

            
            @Override
            public void handle(ActionEvent event) {
                if (textField.getText().equals("")) System.out.println("Input field blank");
                else {

                    data.add(textField.getText());

                    System.out.println("Added Item to List");
                    listView.setItems(data);
                }
            }
        });
        
        SplitPane root = new SplitPane();
        root.setDividerPositions(0.1);
        root.setOrientation(Orientation.VERTICAL);
        root.getItems().add(new FlowPane(addBtn, datePicker, textField));
        root.getItems().add(listView);
        Scene scene = new Scene(root);
        primaryStage.setTitle("YETI by SAD Software, Inc.");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
    
}